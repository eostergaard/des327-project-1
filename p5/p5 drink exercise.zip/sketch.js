function setup() {
 createCanvas(400, 400);
    rectMode(CENTER)
}

function draw() {
  background(220);
  
  fill(127,0,0);
  rect(200, 200, 60, 100);
  
   fill(210,0,0);
  rect(200, 180, 60, 20)
  
  fill(200, 200, 200)
  rect(200, 125, 10, 50)
  
  fill(200, 200, 200)
  rect(200, 150, 70, 10)
  
  fill(200, 200, 200)
  rect(190, 100, 30, 10)
  
  
}